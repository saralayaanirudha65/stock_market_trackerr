package com.example.myapplication1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WatchlistFragment extends Fragment {

    private RecyclerView recyclerView;
    private WatchlistAdapter adapter;
    private AppDatabase db;
    private List<WatchlistStock> stockList;
    private Button btnRefresh;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_watchlist, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewWatchlist);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        btnRefresh = view.findViewById(R.id.btnRefresh); // Make sure this exists in XML!

        db = AppDatabase.getInstance(requireContext());

        btnRefresh.setOnClickListener(v -> loadStocks());

        loadStocks(); // Load once initially

        return view;
    }

    private void loadStocks() {
        new Thread(() -> {
            stockList = db.watchlistDao().getAllStocks();

            requireActivity().runOnUiThread(() -> {
                adapter = new WatchlistAdapter(requireContext(), stockList, stock -> {
                    new Thread(() -> {
                        db.watchlistDao().deleteStock(stock);

                        // Refresh list after deletion
                        stockList = db.watchlistDao().getAllStocks();
                        requireActivity().runOnUiThread(() -> {
                            adapter.updateList(stockList);
                        });
                    }).start();
                });

                recyclerView.setAdapter(adapter);
            });
        }).start();
    }
}
