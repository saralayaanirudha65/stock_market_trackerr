package com.example.myapplication1;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WatchlistDao {

    @Insert
    void insertStock(WatchlistStock stock);

    @Delete
    void deleteStock(WatchlistStock stock);

    @Query("SELECT * FROM watchlist")
    List<WatchlistStock> getAllStocks();
}
