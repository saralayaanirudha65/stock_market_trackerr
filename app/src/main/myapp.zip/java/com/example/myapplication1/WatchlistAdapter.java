package com.example.myapplication1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WatchlistAdapter extends RecyclerView.Adapter<WatchlistAdapter.ViewHolder> {

    public interface OnStockDeleteListener {
        void onDelete(WatchlistStock stock);
    }

    private List<WatchlistStock> stockList;
    private Context context;
    private OnStockDeleteListener deleteListener;

    public WatchlistAdapter(Context context, List<WatchlistStock> stockList, OnStockDeleteListener deleteListener) {
        this.context = context;
        this.stockList = stockList;
        this.deleteListener = deleteListener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPrice, tvPe;
        Button btnDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            tvPe = itemView.findViewById(R.id.tvPe);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public WatchlistAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_watchlist_stock, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WatchlistAdapter.ViewHolder holder, int position) {
        WatchlistStock stock = stockList.get(position);
        holder.tvName.setText(stock.getName() + " (" + stock.getSymbol() + ")");
        holder.tvPrice.setText("₹ " + stock.getPrice());
        holder.tvPe.setText("P/E: " + stock.getPeRatio());

        holder.btnDelete.setOnClickListener(v -> {
            deleteListener.onDelete(stock);
            Toast.makeText(context, stock.getSymbol() + " removed from Watchlist", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

    public void updateList(List<WatchlistStock> newList) {
        stockList.clear();
        stockList.addAll(newList);
        notifyDataSetChanged();
    }
}
