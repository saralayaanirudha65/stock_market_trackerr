package com.example.myapplication1;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.example.myapplication1.R;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private BottomNavigationView bottomNavigationView;
    private TabAdapter tabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Init views
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Setup ViewPager with adapter
        tabAdapter = new TabAdapter(this);
        viewPager.setAdapter(tabAdapter);

        // Sync BottomNavigation with ViewPager
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.nav_search: // <-- error here
                    viewPager.setCurrentItem(0);
                    return true;
                case R.id.nav_holdings:
                    viewPager.setCurrentItem(1);
                    return true;
                case R.id.nav_watchlist:
                    viewPager.setCurrentItem(2);
                    return true;
                case R.id.nav_compare:
                    viewPager.setCurrentItem(3);
                    return true;
            }
            return false;
        });

        // Optional: Sync TabLayout with ViewPager if keeping both
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    switch (position) {
                        case 0: tab.setText("Search"); break;
                        case 1: tab.setText("Holdings"); break;
                        case 2: tab.setText("Watchlist"); break;
                        case 3: tab.setText("Comparison"); break;
                    }
                }).attach();
    }
}
