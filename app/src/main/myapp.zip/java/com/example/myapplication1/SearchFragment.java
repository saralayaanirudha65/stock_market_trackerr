package com.example.myapplication1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SearchFragment extends Fragment {

    EditText etStockSymbol;
    Button btnSearch, btnAddToWatchlist;
    TextView tvResult;

    String currentSymbol = "";
    double currentPrice = 0.0;
    double currentPeRatio = 0.0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        etStockSymbol = view.findViewById(R.id.etStockSymbol);
        btnSearch = view.findViewById(R.id.btnSearch);
        btnAddToWatchlist = view.findViewById(R.id.btnAddToWatchlist);
        tvResult = view.findViewById(R.id.tvResult);

        btnSearch.setOnClickListener(v -> {
            currentSymbol = etStockSymbol.getText().toString().trim().toUpperCase();

            if (!currentSymbol.isEmpty()) {
                // Simulated stock data
                currentPrice = 1523.45;
                currentPeRatio = 24.6;

                String result = "Symbol: " + currentSymbol + "\n"
                        + "Price: ₹" + currentPrice + "\n"
                        + "P/E Ratio: " + currentPeRatio;

                tvResult.setText(result);
            } else {
                Toast.makeText(getContext(), "Enter a stock symbol", Toast.LENGTH_SHORT).show();
            }
        });

        btnAddToWatchlist.setOnClickListener(v -> {
            if (!currentSymbol.isEmpty()) {
                WatchlistStock stock = new WatchlistStock(
                        currentSymbol,
                        currentSymbol + " Ltd",
                        currentPrice,
                        currentPeRatio
                );

                AppDatabase db = AppDatabase.getInstance(requireContext());

                new Thread(() -> {
                    db.watchlistDao().insertStock(stock);
                    requireActivity().runOnUiThread(() ->
                            Toast.makeText(getContext(), currentSymbol + " added to Watchlist", Toast.LENGTH_SHORT).show());
                }).start();
            } else {
                Toast.makeText(getContext(), "Search a stock first", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
