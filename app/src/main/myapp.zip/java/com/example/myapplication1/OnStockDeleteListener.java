package com.example.myapplication1;

public interface OnStockDeleteListener {
    void onDelete(WatchlistStock stock);
}