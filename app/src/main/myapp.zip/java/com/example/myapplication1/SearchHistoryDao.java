package com.example.myapplication1;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface SearchHistoryDao {

    @Insert
    void insertQuery(SearchHistory history);

    @Query("SELECT * FROM search_history ORDER BY id DESC LIMIT 10")
    List<SearchHistory> getRecentQueries();
}
