package com.example.myapplication1;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private BottomNavigationView bottomNavigationView;
    private TabAdapter tabAdapter;
    private ImageButton searchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewPager);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        searchButton = findViewById(R.id.searchButton);

        tabAdapter = new TabAdapter(this);
        viewPager.setAdapter(tabAdapter);

        // Sync BottomNavigation with ViewPager2
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.nav_search:
                    viewPager.setCurrentItem(0);
                    return true;
                case R.id.nav_holdings:
                    viewPager.setCurrentItem(1);
                    return true;
                case R.id.nav_watchlist:
                    viewPager.setCurrentItem(2);
                    return true;
                case R.id.nav_compare:
                    viewPager.setCurrentItem(3);
                    return true;
            }
            return false;
        });

        // Sync ViewPager with BottomNavigation
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                bottomNavigationView.getMenu().getItem(position).setChecked(true);
            }
        });

        // Search button click logic
        searchButton.setOnClickListener(view -> {
            // You can launch a search activity or open a dialog
            Toast.makeText(this, "Search clicked!", Toast.LENGTH_SHORT).show();
        });
    }
}
