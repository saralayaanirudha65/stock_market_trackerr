package com.example.myapplication1;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "holdings")
public class HoldingStock {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String symbol;
    private String name;
    private int quantity;
    private double pricePerStock;
    private double totalValue;

    public HoldingStock(String symbol, String name, int quantity, double pricePerStock, double totalValue) {
        this.symbol = symbol;
        this.name = name;
        this.quantity = quantity;
        this.pricePerStock = pricePerStock;
        this.totalValue = totalValue;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getSymbol() { return symbol; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public double getPricePerStock() { return pricePerStock; }
    public double getTotalValue() { return totalValue; }

    public void setSymbol(String symbol) { this.symbol = symbol; }
    public void setName(String name) { this.name = name; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setPricePerStock(double pricePerStock) { this.pricePerStock = pricePerStock; }
    public void setTotalValue(double totalValue) { this.totalValue = totalValue; }
}
