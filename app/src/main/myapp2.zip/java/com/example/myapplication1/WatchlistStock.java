package com.example.myapplication1;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "watchlist")
public class WatchlistStock {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String symbol;
    private String name;
    private double price;
    private double peRatio;

    public WatchlistStock(String symbol, String name, double price, double peRatio) {
        this.symbol = symbol;
        this.name = name;
        this.price = price;
        this.peRatio = peRatio;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getSymbol() { return symbol; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public double getPeRatio() { return peRatio; }

    public void setSymbol(String symbol) { this.symbol = symbol; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }
    public void setPeRatio(double peRatio) { this.peRatio = peRatio; }
}
